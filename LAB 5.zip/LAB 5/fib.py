L1=[ ]
n= int(input("Enter The Number"))
for i in range(1,n+1):
    L1.append(i)
print(L1)
