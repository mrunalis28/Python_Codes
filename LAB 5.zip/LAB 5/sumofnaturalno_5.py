#Q5: Write a Python program to find the sum of natural numbers up to n using recursive functio

def  sum_Natural_No( n):
    result=sum(n)
    return(result)
    
L1=[ ]
num=int(input("Enter The Number "))
for i in range(1,num+1):
    L1.append(i)
print(L1)
print("Enter The Sum Of Natural number: ",sum_Natural_No(L1))


"""def sum_Natural_No (x):
    if x<=1:
        return x
    else:
        return x+sum_Natural_No(x-1)

num = int(input("enter the number"))
if num>=1:
    print("Enter The Sum Of Natural number:",num, "is",sum_Natural_No (num))

"""
