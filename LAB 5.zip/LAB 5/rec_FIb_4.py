#Q4: Write a Python program to display the Fibonacci sequence up to n-th term by using recursive functions
def  fib_series(n):
    if n==0:
        return 0
    elif n==1:
        return 1
    else:
          return fib_series(n-2)+fib_series(n-1)

L1=[ ]
num = int(input("enter the number"))
for n in range(0,num):
    L1.append(fib_series(n))
print("Fibonacci Series is:",L1)
