#Q6: Write a Python program to convert decimal number into binary number using recursive function

def dec_Bin (x):
     if x>1:
          dec_Bin(x//2)
     print(x % 2,end='')

num = int(input("enter the number"))
if num>=0:
  dec_Bin(num)





