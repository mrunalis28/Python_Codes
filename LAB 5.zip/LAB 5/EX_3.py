#Q3: Write a Python Program to find numbers divisible by thirteen from a list using anonymous function
L1=[11,12,36,26,25,52,98,6,8,5 ]
#n= int(input("Enter The Number"))
#for i in range(1,n+1):
    #L1.append(i)
#print(L1)
print("Numers:",L1)
L2=list(filter(lambda x:(x%13==0),L1))
print("Numers Divisible by 13 are : ",L2)
