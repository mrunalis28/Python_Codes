#Q 1: write a Program to display the Fibonacci sequence up to n-th term where n is provided by the user

def  fib_series(n):
    F1=0
    F2=1
    
    if n==1:
        print(F1)
    else:
        print(F1)
        print(F2)
        for i in range(2,n):
           # 13     5     8
            F3=F1+F2
            #8<- 8
            F1=F2
            #13<- 13
            F2=F3
            print(F3)
            #0 1 1 3 5 8 13........
            

n = int(input("enter the number"))
fib_series(n)


'''
F1=0
F2=1

#  1     0 +1
F3=F1+F2
2      1   +1
F4=F3+F2
# 3  2   +1  
F5=F4+F3
# 5    3 +2  
F6=F5+F4
'''

