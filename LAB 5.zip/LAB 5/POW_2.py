#Q2: Write a Python Program to Display Powers of 2 Using Anonymous Function  ( Lambda function). Take number of terms from us

L1=[ ]
n= int(input("Enter The Number"))
for i in range(1,n+1):
    L1.append(i)
print(L1)
L2=list(map(lambda x:x**2,L1))
print(L2)
