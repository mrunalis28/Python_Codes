#Calculator

a=int(input("enter the first number"))
b=int(input("enter the second number"))
c=a+b
print("Result of Addition is=",c)

a=int(input("enter the first number"))
b=int(input("enter the second number"))
c=a-b
print("Result of substraction is=",c)


a=int(input("enter the first number"))
b=int(input("enter the second number"))
c=a*b
print("Result of multiplication is=",c)

a=int(input("enter the first number"))
b=int(input("enter the second number"))
c=a/b
print("Result of division is=",c)
