 print("Twinkle, twinkle, little star")
 print("How I wonder what you are")
 print("Up above the world so high")
 print("Like a diamond in the sky")
 print("Twinkle, twinkle, little star")
 print("How I wonder what you are")



# print('''Twinkle, twinkle, little star
# How I wonder what you are
# Up above the world so high
# Like a diamond in the sky
# Twinkle, twinkle, little star
# How I wonder what you are''')

