a=input("Name: ")
b=input("age: ")
c=input("address: ")

print(a)
print(b)
print(c)


'''name=input("Enter your name")
age=int(input("Enter your age"))
address=input("Enter address")
print(name,age,address)'''
