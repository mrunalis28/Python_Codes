#area of Triangle

a=float(input("Enter the A"))
b=float(input("Enter the B"))
c=float(input("Enter the C"))
s=(a+b+c)/2
area = (s*(s-a)*(s-b)*(s-c)) ** 0.5 
print('The area of the triangle is %0.2f' %area) 



 #A = (√3)/4 × side2                          
