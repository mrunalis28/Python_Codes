import math

x=int(input("enter the number"))
res=math.sqrt(x)
print(res) 
