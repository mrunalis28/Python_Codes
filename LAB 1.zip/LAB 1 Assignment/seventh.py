num=int(input("enter the 5 digit number:"))
SUM=0
E=num% 10
D=(num/10)%10
C=(num/100)%10
B=(num/1000)%10
A=(num/10000)
print("sum of digit of number is",A+B+C+D+E)

