import math as M
rad=float(input("enter the radious of the circle"))
Area_of_circle=M.pi* rad * rad
print("Area of Circle=",Area_of_circle)
