import math
f=float(input("Enter The Fahrenheit degrees:  "))
Centigrade_D= (f-32)*5/9
print("The Converaion if  Fahrenheit degrees is  %0.2f " %Centigrade_D)
