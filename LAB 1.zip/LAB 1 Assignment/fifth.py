'''import math
import cmath

a=int(input("enter the a"))
b=int(input("enter the b"))
c=int(input("enter the c"))

d = (b**2) - (4*a*c)
res= (-b-cmath.sqrt(d))/(2*a)

print (res)'''

#ax**2+bx+c=0
