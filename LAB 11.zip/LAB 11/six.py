#Q 6: Write a Python program to remove leading zeros from an IP address.For example:
#    IP Address 216.08.094.196 should be represented as 216.8.94.196

import re

num='216.08.094.196'
y=(re.sub('0','',num))
print(y) 
