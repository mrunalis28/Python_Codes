#Q3 : Write a Python program to search some literals strings in a string. 
import re

patterns =[ 'mrunali', 'shinde', '28']
string='mrunali Shinde is on instagram'
match=re.search(patterns,string)
for a in patterns:
    if a==string:
        print("Match : ",match[0])
else:
    print("Not Match")
