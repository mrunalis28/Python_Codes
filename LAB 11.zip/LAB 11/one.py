#Q1: Write a Python program that matches a string that has an a followed by zero or more b's.

import re
string=input("Enter string Zero or more b's :")
match=re.search('^a(b*)$',string)

if match:
    print("Match : ",match[1])
else:
    print("Not Match")
