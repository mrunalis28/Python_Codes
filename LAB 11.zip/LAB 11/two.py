#Q2: Write a Python program to check for a number at the end of a string.
import re

pattern='^[a-z]+\d+$'
string=input("Enter string")
match=re.search(pattern,string)
if match:
    print("Match : ",match[0])
else:
    print("Not Match")
