#4.  Write a program to print each line of a file in reverse order.

file3=open("Test3.txt","r")
var=file3.read()
file3.seek(0)
print(file3.read())
print(var[ : :-1])
file3.close()

