#12: Python program to convert a string to datetime:


      # 'Jul 1 2016  2:43AM' into 2016-07-01 02:43:00
from datetime import datetime

x="Jul 1 2016  2:43 AM"
C=datetime.strptime(x, "%b %d %Y  %I:%M %p")
print(C)
