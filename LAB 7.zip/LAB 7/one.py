#Q1Write a Python program to read first n lines of a file.

File1=open("Test1.txt","w+")
File1.write("This is the Test1 File, I am reading and\n also creating  this file using \n Python File mode  W+.")
File1.seek(0)
print(File1.read())
File1.close()
