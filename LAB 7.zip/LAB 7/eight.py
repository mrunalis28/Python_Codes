#8: Add week ( 7 days) and 12 hours to a given date

from datetime import datetime,timedelta
#x=datetime.today()
x= datetime(2020, 3, 22, 10, 0, 0)

D=print("Date and Time",x.strftime("%Y-%m-%d   %I:%M:%S"))

W=(x+timedelta(weeks=1, hours=12))
print("Date and Time",W.strftime("%Y-%m-%d   %I:%M:%S"))
