#9: Print ten dates, each two a week apart, starting from today, in the form YYYY-MM-DD.


from datetime import timedelta,datetime
x=datetime.today()

print(x.strftime("%Y-%m-%d"))
for i in range(10):
    n_D=(x+timedelta(weeks=2))
    x=n_D
    print(x.strftime("%Y-%m-%d"))
    

