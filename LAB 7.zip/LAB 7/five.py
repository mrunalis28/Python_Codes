#5. Write a Python program to write a list content to a file.
List=["F1","F2","F3","F5","F6"]
File5=open("Test.txt","a+")
File5.writelines(List)
File5.seek(0)
print(File5.read())
File5.close()
