#2. Write a Python program to append text to a file and display the text.

File2=open("Test1.txt","a+")
File2.write(" 'adding this lines at the end of Test1 text file using (a) append mode' ")
File2.seek(0)
print(File2.read())
File2.close()
