#3. Write a Python program to read a file line by line and store it into a list.
file=["F1,F2,F3,F4"]
File2=open("Test2.txt","w+")
File2.writelines(file)
File2.seek(0)
print(File2.readlines())
File2.close()
