#13: Python program to convert Year/Month/Day to Day of Year.

from datetime import datetime,timedelta
x=datetime.now()
C=(x.strftime("%d-%m-%Y"))
print("Date-",C)

start_date=datetime(2022,1,1)
end_date=(x)
print("Year of Day",x -  start_date)

#print("Year of day=",r)
