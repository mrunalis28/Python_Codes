#7: Subtract a week ( 7 days)  from a given date in Python

from datetime import timedelta,datetime
x=datetime.now()

D=(print("DATE before substracting week (7days)-",x.strftime("%d, %B %Y")))
W=x-timedelta(weeks=1)
print("DATE after substracting week (7days) -",W.strftime("%d ,%B %Y"))
