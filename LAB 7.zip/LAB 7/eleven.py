#11:  Write a Python script to display the 
#a) Current date and time
#b) Current year in full
#c) Month of year full name
#d) Weekday of the week
#e) Day of year
#f) Day of the month
#g) Day of week in full name

from datetime import datetime,timedelta
x=datetime.today()
start_date=datetime(2022,1,1)
s_day_Month=(x-timedelta(days=30))
#sdm=s_day_Month.strftime("%d,%B")

print("Current Date and Time=",x.strftime("%d/%m/%Y  %I:%M:%S"))
print("Curret year=",x.strftime("%Y"))
print("Month  year=",x.strftime("%B %Y"))
print("Weekday of the week =",x.strftime("%w"))
print("day of year: ",x-start_date )
print("Day of the month: ",x-s_day_Month )
print("Day of the Week: ",x.strftime("%A"))
