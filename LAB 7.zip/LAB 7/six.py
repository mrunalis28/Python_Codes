#6. Write a program to compute the number of characters, words and lines in a file.

File6=open("Test6.txt","rt")
line=File6.readlines()
File6.seek(0)
char=File6.read()
word=char.split()
print("Number Of lines in Test File are  :  ",len(line))
print("Number Of Charachters in Test File are  :  ",len(char))
print("Number Of Words in Test File are  :  ",len(word))
