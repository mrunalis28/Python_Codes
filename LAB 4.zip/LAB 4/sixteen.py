#Q16: WAP to print the following asterisk pattern:


row=int(input("enter the number of rows "))
for i in range(row+1):
    for j in range(i):
        print("*",end=" ")
    print( )

