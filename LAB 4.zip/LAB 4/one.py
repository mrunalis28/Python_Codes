#Write a python program to add all the odd numbers from 0 to 20.

l1=[x for x in range(21) if x%2==1]
print("list of odd numbers",l1)
print("sum of odd numbers are :",sum(l1))
