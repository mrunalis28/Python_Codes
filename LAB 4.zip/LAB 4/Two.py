#Write a python program to find the sum of all integers greater than 100 and less than 200.


L1=[x for  x in range(100,201)]
print("integers greater than 100 and less than 200\n", L1)
print( "sum of  number are :",sum(L1))
