#Display the following output with the help of Ascii character.
for  x in range(97,123):
    print(x,"=",chr(x))
