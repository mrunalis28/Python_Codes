#Q15: Write a python program to print the Following:
'''1
2  1
3  2  1'''


for i in range(1,4):
    for j in range(i,0,-1):
        print(j,end=" ")
    print()
    
        
