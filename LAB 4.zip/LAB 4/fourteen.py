#Q 14: write a Program to Remove Punctuations from a String provided by the user. [Hint: use punctuation attribute of string module to get all punctuations (i.e. !"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~ ) ]

import string 
a=input("Enter the strintg")
for i in a:
      #if i in string.punctuation:
        if(string.punctuation in a):
            print("Punctuation: ",a)
            
   
