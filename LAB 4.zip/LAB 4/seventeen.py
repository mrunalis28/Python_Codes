
#Q17: WAP to create a function traiangle to print the following asterisk triangle pattern:
row=int(input("enter the number of rows "))
for i in range(row+1):#row
    for j in range(i-4):#coumn
        print("*",end=" ")
    print( )
for i in range(row+1,0,-1):#row
    for j in range(i-4):#coumn
        print("*",end=" ")
    print( )
