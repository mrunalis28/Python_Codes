#Display ascii characters from 48 to 57.
for  x in range(48,58):
    print(x,"=",chr(x))
