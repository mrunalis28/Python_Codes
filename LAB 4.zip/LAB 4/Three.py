#Write a program to display the sum of square of the first ten even natural numbers
#(2*2+ 4*4 + 6*6 + 8*8 + 10*10 + 12*12 + 14 * 14 + 16 * 16 + 18*18 + 20*20)

l1=[x**2 for x in range(21) if x%2==0]
print("Even natural numbers are ",l1)
print("sum of Even naturals numbver arer",sum(l1))

