#Given a Python list. Write a python program to turn every item of a list into its square 
#Expected output:[1, 4, 9, 16, 25, 36, 49]

List1 = [1, 2, 3, 4, 5, 6, 7]
print("List1",List1)
List2=[]
for i in List1:
    s=i*i
    List2.append(s)
print("sqauare of list1 item",List2)
