#Q4: Write a python program to display ascii characters from 65 to 90
for  x in range(65,91):
    print(x,"=",chr(x))
