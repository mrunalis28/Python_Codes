#Q7: Write a python program for given a Python list you should be able to display Python list in the following order
#L1 = [100, 200, 300, 400, 500]
#Expected[500, 400, 300, 200, 100]

L1 = [100, 200, 300, 400, 500]
print(L1)
L1.reverse()
print(L1)
