#Q13:Write a python program to Access the value of key ‘history’ from the following dictionary-sampleDict = {


sampleDict = {"class":{"student":{"name":"Mike", "marks":{ "physics":70,"history":80}}}}


print("Accessing history=",sampleDict['class']['student']['marks']['history'])
