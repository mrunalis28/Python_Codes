#Q9: Write a Python program to add key to a dictionary. Sample Dictionary : {0: 10, 1: 20}
#Expected Result : {0: 10, 1: 20, 2: 30}

dict={0: 10, 1: 20}
print("Dictionary=",dict)
key=2
value=30
dict={0: 10, 1: 20,key:value}
print("Dictionary=",dict)
    
