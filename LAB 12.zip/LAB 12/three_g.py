#g. List the names, city and state of clients who are not in the state of ‘Maharashtra’.

import mysql.connector
con1=mysql.connector.connect(host='localhost',database='lab12',user='root',password='Cdac1234')
cursor=con1.cursor()

qry=""" select name,city from client_master where state <>'Maharashtra' """
cursor.execute(qry)
result=cursor.fetchall()
for i in result:
    print(i)
cursor.close()
con1.close()
