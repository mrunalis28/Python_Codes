#a. List the names of all clients having ‘a’ as the second letter in their names.

import mysql.connector 

connection=mysql.connector.connect(host='localhost',database ='lab12',user='root',password='Cdac1234')
cursor=connection.cursor() 

qry="""select name from client_master where name like  '_a%' """
cursor.execute(qry)
result=cursor.fetchall()
for i in result:
    print(i)
cursor.close()
connection.close()
print("Connection is closed")
