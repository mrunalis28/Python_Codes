#insert into Client_master
mysql> insert into client_master values('C00006','Deepak Sharma','Manglore','560050','Karnataka','0');
Query OK, 1 row affected (0.09 sec)

mysql> select * from client_master;
+----------+----------------+----------+---------+-------------+--------+
| clientno | name           | city     | pincode | state       | baldue |
+----------+----------------+----------+---------+-------------+--------+
| C00001   | Ivan Bayross   | Mumbai   |  400054 | Maharashtra |  15000 |
| C00003   | Chhayaa Bankar | Mumbai   |  400057 | Maharashtra |   5000 |
| C00004   | Ashwini Joshi  | Banglore |  560001 | Karnataka   |      0 |
| C00005   | Hansel Colaco  | Mumbai   |  400060 | Maharashtra |   2000 |
| C00006   | Deepak Sharma  | Manglore |  560050 | Karnataka   |      0 |
+----------+----------------+----------+---------+-------------+--------+
5 rows in set (0.00 sec)
insert into product_master values('P08865','Skirts','5','Piece','75','30','450','300'),('P07975','Lycra Tops','5','Piece','70','30','300','175');
Query OK, 2 rows affected (0.05 sec)
Records: 2  Duplicates: 0  Warnings: 0


# Insert into Product_master
mysql> select * from product_master;
+-----------+--------------+---------------+-------------+-----------+------------+-----------+-----------+
| productno | description  | profitpercent | unitmeasure | qtyonhand | reorderlvl | sellprice | costprice |
+-----------+--------------+---------------+-------------+-----------+------------+-----------+-----------+
| P00001    | T-Shirts     |          5.00 | Piece       |       200 |         50 |    350.00 |    250.00 |
| P03453    | Shirts       |          6.00 | Piece       |       150 |         50 |    500.00 |    350.00 |
| P06734    | Cotton Jeans |          5.00 | Piece       |       100 |         20 |    600.00 |    450.00 |
| P07865    | Jeans        |          5.00 | Piece       |       100 |         20 |    750.00 |    500.00 |
| P07868    | Trousers     |          2.00 | Piece       |       150 |         50 |    850.00 |    550.00 |
| P07885    | Pull Overs   |          2.50 | Piece       |        80 |         30 |    700.00 |    450.00 |
| P07965    | Denim Shirts |          4.00 | Piece       |       100 |         40 |    350.00 |    250.00 |
| P07975    | Lycra Tops   |          5.00 | Piece       |        70 |         30 |    300.00 |    175.00 |
| P08865    | Skirts       |          5.00 | Piece       |        75 |         30 |    450.00 |    300.00 |
+-----------+--------------+---------------+-------------+-----------+------------+-----------+-----------+
9 rows in set (0.00 sec)


#insert into salesman_master

create table salesman_master(salesmanno varchar(6) primary key check(salemanno like 'S%'),salesmanname varchar(20) not null,address1 varchar(30) not null,address2 varchar(30),city varchar(20),pincode int(8),state varchar(20),salamt float(8,2) not null check(salamt !=0),tgttoget float(6,2) not null check(tgttoget!=0),ytdsales float(6,2) not null,remarks varchar(60));
Query OK, 0 rows affected (0.32 sec)

#OR

mysql> insert into salesman_master values('S00003','Raj','P-7','Bandra','Mumbai','400032','Maharashtra','3000','200','100','Good');
Query OK, 1 row affected (0.07 sec)

mysql> insert into salesman_master values('S00004','Ashish','A/5','Juhu','Bombay','400044','Maharashtra','3500','200','150','Good');
Query OK, 1 row affected (0.10 sec)

mysql> select * from salesman_master;
+------------+--------------+----------+----------+--------+---------+-------------+---------+----------+----------+---------+
| salesmanno | salesmanname | address1 | address2 | city   | pincode | state       | salamt  | tgttoget | ytdsales | remarks |
+------------+--------------+----------+----------+--------+---------+-------------+---------+----------+----------+---------+
| S00001     | Aman         | A/14     | Worli    | Mumbai |  400002 | Maharashtra | 3000.00 |   100.00 |    50.00 | Good    |
| S00002     | Omkar        | 65       | Nariman  | Mumbai |  400001 | Maharashtra | 3000.00 |   200.00 |   100.00 | Good    |
| S00003     | Raj          | P-7      | Bandra   | Mumbai |  400032 | Maharashtra | 3000.00 |   200.00 |   100.00 | Good    |
| S00004     | Ashish       | A/5      | Juhu     | Bombay |  400044 | Maharashtra | 3500.00 |   200.00 |   150.00 | Good    |
+------------+--------------+----------+----------+--------+---------+-------------+---------+----------+----------+---------+
4 rows in set (0.00 sec)

# insert into Sales Order
select * from sales_order;
+---------+----------+------------+----------+------------+----------+--------+------------+-------------+
| orderno | clientno | orderdate  | delyaddr | salesmanno | delytype | billyn | delydate   | orderstatus |
+---------+----------+------------+----------+------------+----------+--------+------------+-------------+
| O19001  | C00001   | 2002-06-12 | Delhi    | S00001     | F        | N      | 2002-07-20 | In Process  |
| O19002  | C00003   | 2002-06-25 | Delhi    | S00002     | P        | N      | 2002-07-27 | cancelled   |
| O19003  | C00001   | 2002-04-03 | Delhi    | S00001     | F        | Y      | 2002-04-07 | Fulfilled   |
| O19008  | C00005   | 2002-05-24 | Delhi    | S00004     | F        | N      | 1996-07-26 | In Process  |
| O46866  | C00004   | 2002-05-20 | Delhi    | S00002     | P        | N      | 2002-05-22 | Cancelled   |
+---------+----------+------------+----------+------------+----------+--------+------------+-------------+
5 rows in set (0.00 sec)

#insert into sales_order_details


mysql> insert into sales_order_details values('O19003','P03453','2','2','1050');
Query OK, 1 row affected (0.05 sec)

mysql> select * from sales_order_details;
+---------+-----------+------------+---------+-------------+
| orderno | productno | qtyordered | qtydisp | productrate |
+---------+-----------+------------+---------+-------------+
| O19001  | P00001    |          4 |       4 |      525.00 |
| O19001  | P07965    |          2 |       1 |     8400.00 |
| O19001  | P07885    |          2 |       1 |     5250.00 |
| O19002  | P00001    |         10 |       0 |      525.00 |
| O19008  | P07975    |          5 |       3 |     1050.00 |
| O19008  | P00001    |         10 |       5 |      525.00 |
| O46866  | P07975    |          1 |       0 |     1050.00 |
| O46866  | P07965    |          1 |       0 |     8400.00 |
| O19003  | P06734    |          1 |       1 |    12000.00 |
| O19003  | P03453    |          2 |       2 |     1050.00 |
+---------+-----------+------------+---------+-------------+
10 rows in set (0.00 sec)





