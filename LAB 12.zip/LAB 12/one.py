1. Create the following tables

#Table name: CLIENT_MASTER

mysql> create table client_master(clientno varchar(6),name varchar(20)NOT NULL, city varchar(15),pincode int(8),state varchar(15),baldue float,
             primary key(clientno),check(clientno like 'C%'));

Query OK, 0 rows affected (0.87 sec)

mysql> desc client_master;
+----------+-------------+------+-----+---------+-------+
| Field    | Type        | Null | Key | Default | Extra |
+----------+-------------+------+-----+---------+-------+
| clientno | varchar(6)  | NO   | PRI | NULL    |       |
| name     | varchar(20) | NO   |     | NULL    |       |
| city     | varchar(15) | YES  |     | NULL    |       |
| pincode  | int(8)      | YES  |     | NULL    |       |
| state    | varchar(15) | YES  |     | NULL    |       |
| baldue   | float       | YES  |     | NULL    |       |
+----------+-------------+------+-----+---------+-------+
6 rows in set (0.02 sec)


# product_master
 create table product_master(productno varchar(6),description varchar(15)NOT NULL, profitpercent float(4,2)NOT NULL,unitmeasure varchar(10)NOT NULL,
 qtyonhand int(8)NOT NULL,reorderlvl int(8)NOT NULL,sellprice float(8,2) NOT NULL,costprice float(8,2) NOT NULL, check(costprice>0),check(sellprice>0),
 primary key(productno),check(productno like 'P%'));

Query OK, 0 rows affected (0.83 sec)

mysql> desc product_master;
+---------------+-------------+------+-----+---------+-------+
| Field         | Type        | Null | Key | Default | Extra |
+---------------+-------------+------+-----+---------+-------+
| productno     | varchar(6)  | NO   | PRI | NULL    |       |
| description   | varchar(15) | NO   |     | NULL    |       |
| profitpercent | float(4,2)  | NO   |     | NULL    |       |
| unitmeasure   | varchar(10) | NO   |     | NULL    |       |
| qtyonhand     | int(8)      | NO   |     | NULL    |       |
| reorderlvl    | int(8)      | NO   |     | NULL    |       |
| sellprice     | float(8,2)  | NO   |     | NULL    |       |
| costprice     | float(8,2)  | NO   |     | NULL    |       |
+---------------+-------------+------+-----+---------+-------+
8 rows in set (0.01 sec)

# salesman_master
create table salesman_master(salesmanno varchar(6),salesmanname varchar(20)NOT NULL,address1 varchar(30) NOT NULL,
address2 varchar(30),city varchar(20),pincode int(8),state varchar(20),salamt float(8,2)NOT NULL,tgttoget float(6,2)NOT NULL,
ytdsales float(6,2)NOT NULL,remarks varchar(60),primary key(salesmanno),check(salesmanno like 'S%'),check (salamt>0),check(tgttoget>0));

Query OK, 0 rows affected (1.02 sec)

mysql> desc salesman_master;
+--------------+-------------+------+-----+---------+-------+
| Field        | Type        | Null | Key | Default | Extra|
+--------------+-------------+------+-----+---------+-------+
| salesmanno   | varchar(6)  | NO   | PRI | NULL    |       |
| salesmanname | varchar(20) | NO   |     | NULL    |       |
| address1     | varchar(30) | NO   |     | NULL    |       |
| address2     | varchar(30) | YES  |     | NULL    |       |
| city         | varchar(20) | YES  |     | NULL    |       |
| pincode      | int(8)      | YES  |     | NULL    |       |
| state        | varchar(20) | YES  |     | NULL    |       |
| salamt       | float(8,2)  | NO   |     | NULL    |       |
| tgttoget     | float(6,2)  | NO   |     | NULL    |       |
| ytdsales     | float(6,2)  | NO   |     | NULL    |       |
| remarks      | varchar(60) | YES  |     | NULL    |       |
+--------------+-------------+------+-----+---------+-------+
11 rows in set (0.07 sec)

create table sales_order(orderno varchar(6),clientno varchar(6),orderdate date Not Null,delyaddr varchar(25),salesmanno varchar(6),delytype char(1),billyn char(1),delydate date,orderstatus varchar(10),)


#Sales_Order

mysql> create table sales_order(orderno varchar(6),clientno varchar(6),orderdate date Not Null,delyaddr varchar(25),salesmanno varchar(6),delytype char(1),
            billyn char(1),delydate date,orderstatus varchar(10),primary key(orderno),check (orderno like'O%'),foreign key(clientno) references client_master(clientno),
            foreign key(salesmanno) references salesman_master(salesmanno));

Query OK, 0 rows affected (0.97 sec)

mysql> desc sales_order;
+-------------+-------------+------+-----+---------+-------+
| Field       | Type        | Null | Key | Default | Extra |
+-------------+-------------+------+-----+---------+-------+
| orderno     | varchar(6)  | NO   | PRI | NULL    |       |
| clientno    | varchar(6)  | YES  | MUL | NULL    |       |
| orderdate   | date        | NO   |     | NULL    |       |
| delyaddr    | varchar(25) | YES  |     | NULL    |       |
| salesmanno  | varchar(6)  | YES  | MUL | NULL    |       |
| delytype    | char(1)     | YES  |     | NULL    |       |
| billyn      | char(1)     | YES  |     | NULL    |       |
| delydate    | date        | YES  |     | NULL    |       |
| orderstatus | varchar(10) | YES  |     | NULL    |       |
+-------------+-------------+------+-----+---------+-------+
9 rows in set (0.06 sec)

#Sales_order_details
mysql> create table sales_order_details(orderno varchar(6),productno varchar(6),qtyordered int(8),qtydisp int(8),productrate float(10,2),
            foreign key(orderno) references sales_order(orderno),foreign key(productno) references product_master(productno));
Query OK, 0 rows affected (0.45 sec)

mysql> desc sales_order_details;
+-------------+-------------+------+-----+---------+-------+
| Field       | Type        | Null | Key | Default | Extra |
+-------------+-------------+------+-----+---------+-------+
| orderno     | varchar(6)  | YES  | MUL | NULL    |       |
| productno   | varchar(6)  | YES  | MUL | NULL    |       |
| qtyordered  | int(8)      | YES  |     | NULL    |       |
| qtydisp     | int(8)      | YES  |     | NULL    |       |
| productrate | float(10,2) | YES  |     | NULL    |       |
+-------------+-------------+------+-----+---------+-------+
5 rows in set (0.05 sec)


mysql> show tables;
+---------------------+
| Tables_in_lab12     |
+---------------------+
| client_master       |
| product_master      |
| sales_order         |
| sales_order_details |
| salesman_master     |
+---------------------+
5 rows in set (0.07 sec)



