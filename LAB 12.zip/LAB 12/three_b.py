#b.List the clients who stay in a city whose first letter is ‘M’


import mysql.connector 

connection=mysql.connector.connect(host='localhost',database ='lab12',user='root',password='Cdac1234')
cursor=connection.cursor() 

qry="""select name from client_master where city like  'M%' """
cursor.execute(qry)
result=cursor.fetchall()
for i in result:
    print("name=",i)
cursor.close()
connection.close()

