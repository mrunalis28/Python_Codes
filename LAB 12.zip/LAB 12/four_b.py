#b. Calculating the average quantity sold for each client that has a maximum order value of 15000.00


import mysql.connector
con1=mysql.connector.connect(host='localhost',database='lab12',user='root',password='Cdac1234')
cursor=con1.cursor()

qry=""" select cm.name,avg(sod.qtydisp),so.clientno from client_master cm,sales_order_details sod,sales_order so
            where cm.clientno=so.clientno and so.orderno=sod.orderno group by cm.name having max(sod.qtyordered*sod.productrate)> 15000"""

cursor.execute(qry)
result=cursor.fetchall()
for i in result:
    print("Name:",i [0]," ,","Average:",i [1])

cursor.close()
con1.close()
