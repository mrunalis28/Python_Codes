#a. Printing the description and total quantity sold for each product.

import mysql.connector
con1=mysql.connector.connect(host='localhost',database='lab12',user='root',password='Cdac1234')
cursor=con1.cursor()

qry=""" select pm.description, sum(sod.qtydisp)
             from product_master pm, sales_order_details sod
             where pm.productno = sod.productno group by description;"""

cursor.execute(qry)
result=cursor.fetchall()
for i in result:
    print(" Products : ",i [0])
    print(" Quantity : ",i [1])

cursor.close()
con1.close()
  
