#e. List all information from the Sales_order table for order placed in the month of June

import mysql.connector 

connection=mysql.connector.connect(host='localhost',database ='lab12',user='root',password='Cdac1234')
cursor=connection.cursor() 

qry="""select * from sales_order where month(orderdate)=6 """
cursor.execute(qry)
result=cursor.fetchall()
for row in result:
    print("orderno :",row[0])
    print("clientno :",row[1])
    print("orderdate :",row[2])
    print("delyaddr:",row[3])
    print("salesmanno:",row[4])
    print("delytype:",row[5])
    print("billyn:",row[6])
    print("delydate:",row[7])
    print("orderstatus:",row[8])
    print()
    print("---------------------------------")
cursor.close()
connection.close()

