#f. List the Order No & day on which clients placed their order.

import mysql.connector
con=mysql.connector.connect(host='localhost',database='lab12',user='root',password='Cdac1234')
cursor=con.cursor()

qry=""" select orderno,day(orderdate) from sales_order   """
cursor.execute(qry)
result=cursor.fetchall()
for row in result:
    print("orderno :",row[0])
    print("day :",row[1])
cursor.close()
con.close()
