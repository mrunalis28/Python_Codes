s1=int(input("enter the num1 "))
s2=int(input("enter the  num2 "))
s3=int(input("enter the num3 "))

list1=[s1,s2,s3]
print (list1)

print("Largest number is =  ",max(list1))
