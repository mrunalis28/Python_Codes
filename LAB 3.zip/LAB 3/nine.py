a=input("Enter the string")

if a == a[::-1]:
    print("String  is palindrome")
else:
   print("string is not palindrome")
