#smallest number from the list

List1=[1,55,36,59,88,100,2,3,5]
print(min(List1))
