string=input("Enter the string:")
S=len(string)
if  (S>=3):
    print("Your String is :",string)

    if('ing'in string):
        print( "'ing' in string so replace 'ing' with 'ly' : ", string.replace('ing','ly'))    
    elif('ing'not in string ):
        print("'ing' is not in string apply 'ly' ", string+'ing')
else:
    print("string is not equal to 3")


#if(string.endswith("ing")):
#        print( "'ing' in string so replace 'ing' with 'ly' : ", string.replace('ing','ly'))    
#elif('ing'not in string ):
#        print("'ing' is not in string apply 'ly' ", string+'ing')
#else:
#    print("string is not equal to 3")

