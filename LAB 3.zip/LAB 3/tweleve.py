List=[5,10,15,20,25,50,20]

print(List)
a=20 in List
s=List.index(20)

if (a==True):
    print("20 is available Replace with 200")
    List.pop(3)
    List.insert(3,200)
    print(List)
else:
   print("20 is not in the List")


