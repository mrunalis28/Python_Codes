a=input("enter the string for split")

L1=a.split()

print(L1)
