# print first and last color
color_list = ["Red","Green","White","Black"]
print(color_list[0])
print(color_list[-1])

