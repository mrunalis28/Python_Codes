#Sum of  List elements

List1=[2,3,5,6,7,8]
print(sum(List1))
