s1=int(input("enter the marks of first subject "))
s2=int(input("enter the marks of second subject "))
s3=int(input("enter the marks of third subject "))
s4=int(input("enter the marks of fourth subject "))
s5=int(input("enter the marks of fifth subject "))

total=s1+s2+s3+s4+s5
per=total*100.0 / 500
print("percentage=",per)

if(per>=60):
    print("First Division")
elif(per>=50 or per==59  ):
    print("Second Division")
elif(per>=40 or per==49):
    print("Third Division")
if(per<=40):
    print("Fail")
