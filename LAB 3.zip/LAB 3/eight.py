yr= int(input("Enter a year: "))

if (yr % 400 == 0) and (yr % 100 == 0):
    print(" is a leap year")
elif (yr % 4 ==0) and (yr % 100 != 0):
    print(" is a leap year",yr)
else:
    print("not a leap year",yr)
