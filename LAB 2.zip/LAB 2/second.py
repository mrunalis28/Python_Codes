A=''' i am a sting containing 'single' and "double" quotes '''
print(A)
