A="-"
x=A*50
print(x)
