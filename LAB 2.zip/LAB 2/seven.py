a='mrunali'
b='shinde'

print(a[0:3]+b[4:])
