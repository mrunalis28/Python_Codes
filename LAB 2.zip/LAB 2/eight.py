a="restart"
x=(a[0]+a[1:].replace('r','$'))
print(x)
