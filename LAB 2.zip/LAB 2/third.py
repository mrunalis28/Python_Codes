x=ord('A')
print(x)
