#a='abc xyz'
#x=a.replace(' xyz', 'xbc ayz')
#print(x)
a=' abc'
b=' xyz'
x=a.replace(a[0:3],b[0:3])
y=b.replace(b[0:3],a[0:3])
print ("original string 'abc xyz' ")
print(x + y)

