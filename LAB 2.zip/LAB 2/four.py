A="abc"
x=A*5
print(x)
