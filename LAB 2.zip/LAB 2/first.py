A="Mrunali Chandrakant Shinde 'you can call me mruna' "
print(A)
