A="mrunal"
print(A)
print(A.upper())
