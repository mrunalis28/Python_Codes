#Q2: Write a Python program to access the array element whose index is out of bound and handle the corresponding exception

import sys

try:
    def  IOB():
        List1=[1,3,5,"Mrunali","Cdac",10,11]
        for i in List1:
            print(i)
        print(List1[7])
    IOB()
except:
    print("oops!!!!",sys.exc_info()[1])
    print("You are trying to access the element which is not present in the list")
finally:
    #List1=list.extend((List1[7]))
    #print(List1)
    pass
