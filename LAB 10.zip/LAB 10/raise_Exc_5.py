#Q5: Write a Python Program to depict Raising Exception
try:
    List1=[ ]
    for i in range(5):
        a=int(input("Enter numbers divided by 2  : "))
        if (a%2==0):
            List1.append(a)
            
        else:
            raise ValueError

except ValueError:
    print("Number is not Divided by 2 ")

finally:
    print(List1)




