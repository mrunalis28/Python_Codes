#Q9: Write a python program to raise an error and stop the program if x is lower than 0.


import sys
class InvalidValueError(Exception):
        '''Error'''
class NegativeValueError(Exception):
        '''Error'''
        
while True:
        try:
                x=int(input("Enter The  Value :"))
                if x>0:
                        print("You Have Enterd Correct Value\n")
                elif x==0:
                        raise InvalidValueError
                elif x<0:
                        raise NegativeValueError
                else:
                         print("Program is End")
                         break
                        
                
        except InvalidValueError:
                print(sys.exc_info()[0])
                print("Enter theValue greater than 0")
                
        except NegativeValueError:
                 print(sys.exc_info()[0])
                 print("Negative Value Error")
                
                        
        finally:
               pass
