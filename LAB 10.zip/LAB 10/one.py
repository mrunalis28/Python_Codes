#Q1: Write a function to compute 5/0 and use try/except to catch the exceptions.
import sys

try:

    def one():
        x=5
        i=5
        while x>=0:
            res=i//x
            x=x-1
            print(res)
    one()
except:
    print("oops!",sys.exc_info()[0])
    print("Can't divide by ZERO")

finally:

    pass
