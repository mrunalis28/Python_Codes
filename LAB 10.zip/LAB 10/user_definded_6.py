#Q6: Write a python program to create user-defined exception

class Exc(Exception):
    """User Defined Exception"""

while True:
    a=int(input("Enter any  numbers less than 10"))
    try:
        List1=[ ]
        if a <= 10:
            List1.append(a)
        else:
            raise Exc

    except Exc:
            print("Error Number is Greater")
    finally:
            print(List1)

    



