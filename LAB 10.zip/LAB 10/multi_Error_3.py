#Q3: Write a Python  Program to handle multiple errors with one except statement

import sys

try:
    def one():
        x=5
        i=5
        while x>=0:
            res=i//x
            x=x-1
            print(res)
    #one()

    def  IOB():
        List1=[1,3,5,"Mrunali","Cdac",10,11]
        print(List1 ,end=" ")
        print(List1[7])
    IOB()
  
    
except (ZeroDivisionError,IndexError):
    print("\noops!!",sys.exc_info()[0])
    
    
finally:
    pass
    



