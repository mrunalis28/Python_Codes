#Q7: Print one message if the try block raises a NameError and another for other errors:
import sys
try:
    x = 2
    y="mr"
    value = 10
    print("Value : ", value)
    print(x/y)

except NameError:
        print(sys.exc_info()[0])
        print("Please check variable",sys.exc_info()[1])

except TypeError :
         print(sys.exc_info()[0])
         print("Division not possible of int and str",sys.exc_info()[1])
  
