#Q10: Write a python program to raise a TypeError if x is not an integer:
import sys
x=input("Enter the integer number : ")
    
try:
    if (x.isnumeric()):
        print("Correct Value")
    else:
        raise TypeError

except:
        print("oops!!",sys.exc_info()[0])
        print("Enter Numeric Value only")

finally:
    print("You have entered Value is "," ' ",x," ' ")
