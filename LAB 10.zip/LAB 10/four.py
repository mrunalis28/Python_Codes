#Q4: Write a Python Program to depict else clause with try-except
import sys
try:
    def method():
        a=int(input("Enter Number Which is greater Than 50 "))
        if a<=50:
            raise ValueError
        else:
            for i in range(a):
                print(i,end=" ")
           
    method()

except ValueError:
    print(sys.exc_info()[0])
    print("Enter Value which is Greater than 50 ",sys.exc_info()[1])

finally:
    print("\n")
    print("Enter Value Again\n")
    method()
