#Q8: Try to open and write to a file that is not writable:
import io 
import sys
try:
    File1=open("Exception_Handling.txt","r")
    File1.write("Exception Handling")
    File1.seek(0)
    print(File1.read())

except io.UnsupportedOperation:
    print(sys.exc_info()[0])
    print(" Change File mode")

finally:
    File1.close()


