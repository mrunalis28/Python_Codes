s1=input('Enter String s1 :')
s2=input('Enter String s2 :')
l=(len(s1))//2
s3=s1[0:2]+s2+s1[-2:]
print('New String s3 :',s3)

