tuple1 = ("Orange", [10, 20, 30], (5, 15, 25))
print(tuple1[1][1])
