tuple1 = (10, 20, 30, 40)
print(tuple1)
print(type(tuple1))
a,b,c,d=tuple1

print(a,b,c,d)

print(type(a))
