list1 = [54, 44, 27, 79, 91, 41]
print(list1)

#list1.remove(list1[4])
list1.pop()
print ("List after removing element at index 4=",list1)
list1.insert(2,66)
print ("List after adding element at index 2=",list1)
list1.append(89)
print ("List after adding element at last=",list1)

