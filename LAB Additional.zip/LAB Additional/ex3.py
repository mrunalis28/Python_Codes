s1="Chankant"
s2="dra"
mid=(0+len(s1))//2
s3=s1[0:mid]+s2+s1[mid:]
print(s3)
