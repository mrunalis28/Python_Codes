#1
String="Mrunali Chandrakant Shinde"
print("Mrunali Chandrakant Shinde")
String2=print("First Middle and  Last charachters are: ",String[0]+String[8]+String[20])

