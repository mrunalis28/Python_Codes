 
l1 = [3, 6, 9, 12, 15, 18, 21]
l2 = [4, 8, 12, 16, 20, 24, 28]

odd_index=l1[1: :2]
print(odd_index)

Even_index=l2[0: :2]
print(Even_index)

L3=print("Final List",odd_index+Even_index)

