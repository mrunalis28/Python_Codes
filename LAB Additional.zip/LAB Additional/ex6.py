tuple1=(50,)
print(tuple1[0])
print(type(tuple1))
