tuple1=(11, [22, 33], 44, 55)
print(tuple1)
tuple1[1][0]=222
print(tuple1)
