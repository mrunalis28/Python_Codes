list1 = [10, 20, [300, 400, [5000, 6000], 500], 30, 40]
print(list1)
list1[2][2].extend([7000])
print(list1)

  
