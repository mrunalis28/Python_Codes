tuple1 = (11, 22)
tuple2 = (99, 88)
print("tuple1=",tuple1)
print("tuple2=",tuple2)
tuple3=tuple1
tuple1=tuple2
tuple2=tuple3
print("tuple1=",tuple1)
print("tuple2=",tuple2)

