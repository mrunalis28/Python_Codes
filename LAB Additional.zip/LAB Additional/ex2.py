#2
String=input("Enter the String")
mid=(0+len(String))//2
print(mid)
print(String[mid-1]+String[mid]+String[mid+1])
