#1. Define a class to represent a bank account. Include the following 
#members: 
#Data Members:
#a.Name of the Depositor
#b.Account Number
#c.Type of Account
#d.Balance amount in the account
#Data Methods:
#a.To assign initial values
#b.To deposit an amount
#c.To withdraw an amount
#d.To display name and balance.

class Bank:
    Balance=500
    def method_A(self): #New_Customer
        self.name1=input("Enter The Name Of Customer : ")
        self.Acc_no=int(input("Enter The Account No : "))
        self.Type_Acc=input("Enter The Account Type(Saving or Current) : ")
        
        
    def method_B(self): #Deposit Case
        self.name1=input("Enter Youre Name : ")
        self.D_amount=int(input("Enter The Amount For Deposit : "))
        Bank.Balance=Bank.Balance+self.D_amount
        print("Cash Deposited Successfully in Youre Account ")
        #print(Bank.Balance)
      
        
    def method_C(self): #Withdrawal_case
        self.name1=input("Enter Youre |Name : ")
        self.w_amount=int(input("Enter The Withdrawal Amount : "))
        if self.w_amount<=Bank.Balance:
            Bank.Balance=Bank.Balance-self.w_amount
            print("Collect You're Cash  ")
        else:
             print("Insufficient Balance")
        #print(self.w_amount)

    def method_d(self):
        print("Name=> " ,self.name1)
        print("Account Balance=> ",Bank.Balance)

    def menu(self):
        while True:
            print("1.New customer \n2.Deposit \n3.Withdrawal \n4.Display \n5.Exit")
            choice=int(input("Enter Youre Choice"))
            if choice==1:
                self.method_A()
            elif choice==2:
                self.method_B()
            elif choice==3:
                self.method_C()
            elif choice==4:
                self.method_D()
            else:
                print("End Of Transaction")
                break


                 #ORRRRRR
            
'''        
    def menu(self):
         print("1.New customer \n2.Deposit \n3.Withdrawal \n4.Display \n5.Exit")
         ch=int(input("Enter Youre Choice"))
         if ch==1:
             Bank.method_A(self)
             m=input("Do You Want to Continue(y or n): ")
             if m=='y':
                  Bank.menu(self)
             elif m=='n':
                 print("End of the Transaction")
             else:
                 print("wrong Choice")
                 
         elif ch==2:
            Bank.method_B(self)
            m=input("Do You Want to Continue(y or n): ")
            if m=='y':
                  Bank.menu(self)
            elif m=='n':
                 print("End of the Transaction")
            else:
                 print("wrong Choice")
         elif ch==3:
             Bank.method_C(self)
             m=input("Do You Want to Continue(y or n): ")
             if m=='y':
                  Bank.menu(self)
             elif m=='n':
                 print("End of the Transaction")
             else:
                 print("wrong Choice")
         elif ch==4:
             Bank.method_d(self)
             m=input("Do You Want to Continue(y or n): ")
             if m=='y':
                  Bank.menu(self)
             elif m=='n':
                 print("End of the Transaction")
             else:
                 print("wrong Choice")
         else:
            print("End Of Transaction")
'''








            
