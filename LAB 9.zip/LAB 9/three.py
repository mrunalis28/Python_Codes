#3.Write program to create a base class staff with code and name. Derive classes 
#teacher(subject , publication) , typist (speed) , officer (grade) . Using the typist class as 
#base class,create two classes regular(salary) and casual(daily wages).Implement a 
#menu driven program for the same.
#Output:
#1. Teacher
#2. Officer,
#3. Regular Typist
#4. Casaul typist
#5. Exi


class staff:
    def  method_staff(self):
        self.staff_Name=input("Enter The Name : ")
        self.staff_Code=int(input("Enter the Code :"))

class Teacher(staff):
    def method_Teacher(self):
        super(Teacher,self).method_staff()
        self.Subject="Python Programming"
        print("Subject is: ",self.Subject)
        self.Publication="RR Publication"
        print("Publication Name is: ",self.Publication)

class Typist(staff):
    def method_Typist(self):
        super(Typist,self).method_staff()
        self.speed="40-wpm"
        print("Speed of Typist is : ",self.speed) 


class Officer(staff):
    def method_Officer(self):
        super(Officer,self).method_staff()
        self.grade="A+"
        print("Grade are: ",self.grade)
        

class Regular(Typist):     
    def method_Regular(self):
        super(Regular,self).method_Typist()
        self.salary=30000
        print("Salary of Typist is : ",self.salary)
    
class Casual(Typist):
    def method_Casual(self):
        super(Casual,self).method_Typist()
        self.daily_wages=600
        print("Daily Wages of Typist is: ",self.daily_wages)
        
    
class menu:
    while True:
            
            print("\n\n1.Teacher \n2.Officer \n3.Regular Typist \n4.Casual Typist\n5.Exit")
            choice=int(input("Enter Youre Choice"))
            if choice==1:
                t=Teacher()
                t.method_Teacher()
            elif choice==2:
                o=Officer()
                o.method_Officer()
            elif choice==3:
                r=Regular()
                r.method_Regular()
            elif choice==4:
                c=Casual()
                c.method_Casual()
            else:
                print("You are Exited Successfully")
                break
