#2. Write a program to implement following. 
#Create a base class named person consisting of name and code.
#Create 2 child classes
#a) Account with member_pay
#b) Admin with experience and inherit the base class.
#Create a class employee with name, code, experience and pay by inheriting the above classes.


class person:
    def info(self):
        self.name=input("Enter The Name of Employee")
        self.code=int(input("Enter the Code Of Employee"))

class Account(person):  #child class
    def member_pay(self):
        if self.exp>=3:
            self.salary=50000
        else:
            self.salary=30000
        
class Admin(person): #child class
    def experince(self):
        self.exp=int(input("Enter The Employee Experinece"))
        
    def display(self):
        self.info()
        self.experince()
        self.member_pay()
        print("Salary of Employee",self.name,"is",self.salary)      #we can not access the member of persons class so we use  admin class for that through admin we are accsing the persos member and
                                                                                            #we are acccessing admin in employee class
       

class employe(Admin,Account):                                           #child class of Account and Employe
    pass
    
    
