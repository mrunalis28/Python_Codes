#Q1
class Triangle:
    
    number_of_sides=3
    def __init__(self,angle1,angle2,angle3):
        self.anglex=angle1
        self.angley=angle2
        self.anglez=angle3

    def check_angles(self,):
        sum1=self.anglex+self.angley+self.anglez
        print("sum=",sum)
        if(sum1==180):
            return True
        else:
            return False
        

            

    



'''
obj1=Triangle(10,20,30)
obj1.check_angles()
False
obj1.anglex=20
obj1.angley=70
obj1.anglez=90
obj1.check_angles()
True
'''
