 #Q5: Write a program to find the area and perimeter of a rectangle using classes and objects. 
#Program output should be like this

class Rectangle:

    def Area_Peri_Rect(self):
        self.area=int(input("Enter Length of a Rectangle : "))
        self.perimeter=int(input("Enter Breadth of a Rectangle : "))

    def calculate(self):
        print("1.Area \n 2.Perimeter \n 3.Exit")
        ch=int(input("Enter Youre Choice"))
        if ch==1:
            print("Area of Rectangle with length",self.area,"and","breadth",self.perimeter,"is",self.area*self.perimeter) 
        elif ch==2:
            print("perimeter of Rectangle with length",self.area,"and","breadth",self.perimeter,"is",2*(self.area+self.perimeter))
        else:
            print("End of the program")
