#Q4: Write a Python class which has two methods get_String and print_String. get_String accept 
#a string from the user and print_String print the string in upper case.

class python:

    def get_String(self):
        self.string1=input("Enter The String : >>")
        

    def print_String(self):
        self.string1
        m=self.string1.upper()
        print(m)
'''
#output
>>obj1=python()
>>obj1.get_String()
enter the stringmrunali
>>obj1.print_String()
MRUNALI
'''
